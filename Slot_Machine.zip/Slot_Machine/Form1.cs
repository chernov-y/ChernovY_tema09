﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlotMachine
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.Timer spinTimer;
        private int currentCycle = 0;
        private int totalCycles = 0;
        private Random random = new Random();
        private bool isInitialized = false;

        public Form1()
        {
            InitializeComponent();
            
            // Inițializează cronometrul pentru animația de rotire
            spinTimer = new System.Windows.Forms.Timer();
            spinTimer.Interval = 50; // Actualizează la fiecare 50ms pentru o animație fluidă
            spinTimer.Tick += SpinTimer_Tick;

            // Adaugă evenimentul Form Load pentru a inițializa sloturile după încărcarea controalelor
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Așteaptă puțin pentru ca contextele OpenGL să fie pregătite
            System.Threading.Thread.Sleep(100);
            
            // Inițializează sloturile cu texturi vizibile aleatorii
            int textureCount = SlotControl.GetTextureCount();
            if (textureCount > 0)
            {
                slot1.SetVisibleTexture(random.Next(textureCount));
                slot2.SetVisibleTexture(random.Next(textureCount));
                slot3.SetVisibleTexture(random.Next(textureCount));
                isInitialized = true;
            }
        }

        private void spinButton_Click(object sender, EventArgs e)
        {
            if (!isInitialized) return;

            // Dezactivează butonul și input-ul în timpul rotirii
            spinButton.Enabled = false;
            cyclesNumeric.Enabled = false;
            resultLabel.Text = "";

            // Începe rotirea
            totalCycles = (int)cyclesNumeric.Value;
            currentCycle = 0;

            slot1.StartSpinning();
            slot2.StartSpinning();
            slot3.StartSpinning();

            spinTimer.Start();
        }

        private void SpinTimer_Tick(object sender, EventArgs e)
        {
            // Actualizează rotația pentru toate sloturile
            slot1.UpdateRotation();
            slot2.UpdateRotation();
            slot3.UpdateRotation();

            // Verifică dacă am completat ciclul curent (0.5 secunde = 500ms, 10 tick-uri la 50ms)
            if (spinTimer.Tag == null)
                spinTimer.Tag = 0;

            int tickCount = (int)spinTimer.Tag + 1;
            spinTimer.Tag = tickCount;

            if (tickCount >= 10) // 10 tick-uri * 50ms = 500ms = 0.5 secunde
            {
                currentCycle++;
                spinTimer.Tag = 0;

                if (currentCycle >= totalCycles)
                {
                    // Oprește rotirea
                    spinTimer.Stop();
                    slot1.StopSpinning();
                    slot2.StopSpinning();
                    slot3.StopSpinning();

                    // Setează texturile finale vizibile aleatoriu
                    int textureCount = SlotControl.GetTextureCount();
                    int result1 = random.Next(textureCount);
                    int result2 = random.Next(textureCount);
                    int result3 = random.Next(textureCount);

                    slot1.SetVisibleTexture(result1);
                    slot2.SetVisibleTexture(result2);
                    slot3.SetVisibleTexture(result3);

                    // Verifică dacă există un câștig - bazat pe textura frontală vizibilă, nu pe poziția cubului
                    if (result1 == result2 && result2 == result3)
                    {
                        resultLabel.Text = "🎉 AI CÂȘTIGAT! 🎉";
                        resultLabel.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        resultLabel.Text = "Ai Pierdut. Încearcă Din Nou!";
                        resultLabel.ForeColor = System.Drawing.Color.Red;
                    }

                    // Reactivează controalele
                    spinButton.Enabled = true;
                    cyclesNumeric.Enabled = true;
                }
            }
        }
    }
}