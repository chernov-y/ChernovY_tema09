using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;

namespace SlotMachine
{
    public class SlotControl : GLControl
    {
        private float rotationAngle = 0f;
        private bool isSpinning = false;
        private Random random = new Random();
        private static int[] textureIds = null;
        private static int textureCount = 0;
        
        // Urmărește care textură este vizibilă momentan pe fața frontală
        private int visibleFrontTexture = 0;

        public SlotControl() : base(new GraphicsMode(32, 24, 0, 4))
        {
            this.Paint += SlotControl_Paint;
            this.Resize += SlotControl_Resize;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            MakeCurrent();
            GL.ClearColor(Color.FromArgb(50, 50, 50));
            GL.Enable(EnableCap.DepthTest);
            GL.Enable(EnableCap.Texture2D);
            
            // Încarcă texturile o singură dată
            if (textureIds == null)
            {
                LoadTextures();
            }
            
            SetupViewport();
        }

        private void LoadTextures()
        {
            string assetsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "assets");
            if (!Directory.Exists(assetsPath))
            {
                assetsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets");
            }

            string[] imageFiles = Directory.GetFiles(assetsPath, "*.png");
            textureCount = imageFiles.Length; // Folosește TOATE imaginile
            textureIds = new int[textureCount];
            GL.GenTextures(textureCount, textureIds);

            for (int i = 0; i < textureCount; i++)
            {
                Bitmap bitmap = new Bitmap(imageFiles[i]);
                BitmapData data = bitmap.LockBits(
                    new Rectangle(0, 0, bitmap.Width, bitmap.Height),
                    ImageLockMode.ReadOnly,
                    System.Drawing.Imaging.PixelFormat.Format32bppArgb);

                GL.BindTexture(TextureTarget.Texture2D, textureIds[i]);
                GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba,
                    data.Width, data.Height, 0,
                    OpenTK.Graphics.OpenGL.PixelFormat.Bgra,
                    PixelType.UnsignedByte, data.Scan0);

                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);

                bitmap.UnlockBits(data);
                bitmap.Dispose();
            }
        }

        private void SlotControl_Resize(object sender, EventArgs e)
        {
            MakeCurrent();
            SetupViewport();
        }

        private void SetupViewport()
        {
            GL.Viewport(0, 0, Width, Height);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();

            float aspect = (float)Width / (float)Height;
            Matrix4 perspective = Matrix4.CreatePerspectiveFieldOfView(
                MathHelper.DegreesToRadians(45.0f), aspect, 0.1f, 100.0f);
            GL.LoadMatrix(ref perspective);

            GL.MatrixMode(MatrixMode.Modelview);
        }

        private void SlotControl_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            MakeCurrent();
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            GL.LoadIdentity();
            GL.Translate(0.0f, 0.0f, -5.0f);
            GL.Rotate(rotationAngle, 0.0f, 1.0f, 0.0f);
            GL.Rotate(20.0f, 1.0f, 0.0f, 0.0f);

            DrawCube();

            SwapBuffers();
        }

        private void DrawCube()
        {
            GL.Color3(1.0f, 1.0f, 1.0f); // Culoare albă pentru a afișa texturile corect

            // Vom folosi 6 texturi diferite pentru cele 6 fețe ale cubului
            // Fața frontală (orientată spre privitor) va determina condiția de câștig
            
            // Fața frontală - aceasta este textura vizibilă
            GL.BindTexture(TextureTarget.Texture2D, textureIds[visibleFrontTexture % textureCount]);
            GL.Begin(PrimitiveType.Quads);
            GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.End();

            // Fața din spate
            GL.BindTexture(TextureTarget.Texture2D, textureIds[(visibleFrontTexture + 1) % textureCount]);
            GL.Begin(PrimitiveType.Quads);
            GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.End();

            // Fața de sus
            GL.BindTexture(TextureTarget.Texture2D, textureIds[(visibleFrontTexture + 2) % textureCount]);
            GL.Begin(PrimitiveType.Quads);
            GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.End();

            // Fața de jos
            GL.BindTexture(TextureTarget.Texture2D, textureIds[(visibleFrontTexture + 3) % textureCount]);
            GL.Begin(PrimitiveType.Quads);
            GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.End();

            // Fața din dreapta
            GL.BindTexture(TextureTarget.Texture2D, textureIds[(visibleFrontTexture + 4) % textureCount]);
            GL.Begin(PrimitiveType.Quads);
            GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.End();

            // Fața din stânga
            GL.BindTexture(TextureTarget.Texture2D, textureIds[(visibleFrontTexture + 5) % textureCount]);
            GL.Begin(PrimitiveType.Quads);
            GL.TexCoord2(0.0f, 1.0f); GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.TexCoord2(1.0f, 1.0f); GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.TexCoord2(1.0f, 0.0f); GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.TexCoord2(0.0f, 0.0f); GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.End();
        }

        public void SetVisibleTexture(int textureIndex)
        {
            visibleFrontTexture = textureIndex % textureCount;
            // Resetează rotația pentru a afișa clar fața frontală
            rotationAngle = 0f;
            Invalidate();
        }

        public int GetVisibleTexture()
        {
            return visibleFrontTexture;
        }

        public void StartSpinning()
        {
            isSpinning = true;
        }

        public void StopSpinning()
        {
            isSpinning = false;
        }

        public void UpdateRotation()
        {
            if (isSpinning)
            {
                rotationAngle += 30f;
                if (rotationAngle >= 360f)
                    rotationAngle -= 360f;
                
                // Schimbă aleatoriu textura vizibilă în timpul rotirii
                visibleFrontTexture = random.Next(textureCount);
            }
            Invalidate();
        }

        public static int GetTextureCount()
        {
            return textureCount;
        }
    }
}