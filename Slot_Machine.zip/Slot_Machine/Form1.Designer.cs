﻿namespace SlotMachine
{
    partial class Form1
    {
        /// <summary>
        /// Variabilă necesară pentru designer.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Curăță toate resursele utilizate.
        /// </summary>
        /// <param name="disposing">adevărat dacă resursele gestionate trebuie eliminate; altfel, fals.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Cod generat automat de Windows Forms Designer

        /// <summary>
        /// Metodă necesară pentru suportul Designerului - nu modificați 
        /// conținutul acestei metode cu editorul de cod.
        /// </summary>
        private void InitializeComponent()
        {
            this.slot1 = new SlotMachine.SlotControl();
            this.slot2 = new SlotMachine.SlotControl();
            this.slot3 = new SlotMachine.SlotControl();
            this.spinButton = new System.Windows.Forms.Button();
            this.cyclesNumeric = new System.Windows.Forms.NumericUpDown();
            this.cyclesLabel = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.cyclesNumeric)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // slot1
            // 
            this.slot1.BackColor = System.Drawing.Color.Black;
            this.slot1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.slot1.Location = new System.Drawing.Point(5, 5);
            this.slot1.Name = "slot1";
            this.slot1.Size = new System.Drawing.Size(140, 140);
            this.slot1.TabIndex = 0;
            this.slot1.VSync = false;
            // 
            // slot2
            // 
            this.slot2.BackColor = System.Drawing.Color.Black;
            this.slot2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.slot2.Location = new System.Drawing.Point(5, 5);
            this.slot2.Name = "slot2";
            this.slot2.Size = new System.Drawing.Size(140, 140);
            this.slot2.TabIndex = 1;
            this.slot2.VSync = false;
            // 
            // slot3
            // 
            this.slot3.BackColor = System.Drawing.Color.Black;
            this.slot3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.slot3.Location = new System.Drawing.Point(5, 5);
            this.slot3.Name = "slot3";
            this.slot3.Size = new System.Drawing.Size(140, 140);
            this.slot3.TabIndex = 2;
            this.slot3.VSync = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.slot1);
            this.panel1.Location = new System.Drawing.Point(50, 50);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(150, 150);
            this.panel1.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gold;
            this.panel2.Controls.Add(this.slot2);
            this.panel2.Location = new System.Drawing.Point(225, 50);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(150, 150);
            this.panel2.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gold;
            this.panel3.Controls.Add(this.slot3);
            this.panel3.Location = new System.Drawing.Point(400, 50);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(5);
            this.panel3.Size = new System.Drawing.Size(150, 150);
            this.panel3.TabIndex = 9;
            // 
            // spinButton
            // 
            this.spinButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spinButton.Location = new System.Drawing.Point(225, 290);
            this.spinButton.Name = "spinButton";
            this.spinButton.Size = new System.Drawing.Size(150, 50);
            this.spinButton.TabIndex = 3;
            this.spinButton.Text = "Învârte!";
            this.spinButton.UseVisualStyleBackColor = true;
            this.spinButton.Click += new System.EventHandler(this.spinButton_Click);
            // 
            // cyclesNumeric
            // 
            this.cyclesNumeric.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cyclesNumeric.Location = new System.Drawing.Point(315, 240);
            this.cyclesNumeric.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.cyclesNumeric.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.cyclesNumeric.Name = "cyclesNumeric";
            this.cyclesNumeric.Size = new System.Drawing.Size(60, 26);
            this.cyclesNumeric.TabIndex = 4;
            this.cyclesNumeric.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // cyclesLabel
            // 
            this.cyclesLabel.AutoSize = true;
            this.cyclesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cyclesLabel.Location = new System.Drawing.Point(175, 243);
            this.cyclesLabel.Name = "cyclesLabel";
            this.cyclesLabel.Size = new System.Drawing.Size(134, 17);
            this.cyclesLabel.TabIndex = 5;
            this.cyclesLabel.Text = "Cicluri de Învârtire:";
            // 
            // resultLabel
            // 
            this.resultLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultLabel.Location = new System.Drawing.Point(50, 360);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(500, 40);
            this.resultLabel.TabIndex = 6;
            this.resultLabel.Text = "";
            this.resultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 420);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.cyclesLabel);
            this.Controls.Add(this.cyclesNumeric);
            this.Controls.Add(this.spinButton);
            this.Name = "Form1";
            this.Text = "Slot Machine";
            ((System.ComponentModel.ISupportInitialize)(this.cyclesNumeric)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SlotControl slot1;
        private SlotControl slot2;
        private SlotControl slot3;
        private System.Windows.Forms.Button spinButton;
        private System.Windows.Forms.NumericUpDown cyclesNumeric;
        private System.Windows.Forms.Label cyclesLabel;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}